
char *ftoa(char *a, double f, int precision);

void serialPrintf(const char *format, ...);