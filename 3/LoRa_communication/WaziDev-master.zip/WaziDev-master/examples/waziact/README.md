# WaziAct

This example, reads an analogue sensor connected to `A6` powered by `D6` transmits the value to the gateway then it waits for a downlink to arrive.
The received value will be a number indicating that how many seconds the `Relay` should be closed.

The relay can be triggered via pin `D7`.
