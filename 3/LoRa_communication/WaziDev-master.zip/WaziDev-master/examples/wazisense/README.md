# WaziSense

This example, reads the onboard `SI7021` sensor, the value of the solar panel (Connected to `A2` via a voltage divider) and pushes them to the LoRaWAN gateway periodically.
