This folder contains drivers for the CH340 chip, used by WaziDev.

WARNING: most of modern OS already support the CH340. You probably don't need to install any driver.
