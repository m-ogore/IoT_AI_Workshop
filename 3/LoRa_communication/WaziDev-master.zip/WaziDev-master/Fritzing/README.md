# Fritzing

This folder contains parts for the [Fritzing software](https://fritzing.org/).

Import the `WaziDev fzpz` file into you Fritzing parts folder to use the WaziDev with you sketches.

![Example Sketch](ExampleSketch.svg)